#ifndef _INPUT_
#define _INPUT_

#include <string>
#include <stdexcept>


bool checkIfNum(std::string & str);

#endif

